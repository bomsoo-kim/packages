#ref) https://python-packaging.readthedocs.io/en/latest/command-line-scripts.html
from .xgrid_search import *

__version__ = '2019-07-27-beta'

